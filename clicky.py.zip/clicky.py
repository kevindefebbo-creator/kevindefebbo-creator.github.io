import webbrowser
from time import sleep
import keyboard

good_links = [
"http://www.warrencountyschools.org/olc/13538/page/161333",
"https://www.warrenkyschools.org/olc/13538",
"https://www.facebook.com/bgdailynews/posts/city-manager-kevin-defebbo-said-the-city-has-been-offering-tax-incentives-for-ar/10154394682221346/",
"https://www.bgdailynews.com/news/city-manager-defebbo-stepping-down/article_72a04155-2fa7-5e4c-a5a4-39329a12f792.html",
"https://www.bgdailynews.com/news/city-manager-hired/article_fde16748-120a-5fbc-bf86-66cda981ba0f.html",
"https://www.bgamplifier.com/kevin-defebbo/image_747e95dd-0a23-5a2a-9eac-2d0f78ac9797.html",
"https://govsalaries.com/defebbo-kevin-d-8389027",
"https://www.wkyufm.org/post/new-city-manager-named-bowling-green",
"https://www.wnky.com/bowling-greens-city-manager-announces-retirement/",
"https://elgl.org/tag/kevin-defebbo/",
"http://buffalonews.com/news/article_2be81948-cf6e-5fd8-81e3-ace14b6a820d.html",
"https://taxpayersunitedofamerica.org/note-to-kentucky-top-bowling-green-government-pension-estimates-released/",
"https://www.manorisd.net/domain/1051",
"https://www.weirtondailytimes.com/obituaries/2020/05/sister-anne-defebbo/",
"https://www.wbko.com/content/news/Bowling-Greens-City-Manager-is-retiring--467941243.html",
"https://publicreports.com/name/Kevin-Defebbo-G9H5GaF",
"https://www.linkedin.com/pub/dir/+/Defebbo",
"https://twitter.com/kevinrdefebbo?lang=en",
"https://www.pinterest.com/kdefebbo/",
"https://osfphila.org/obituaries/sister-anne-dorice-defebbo-dies-at-the-age-of-72/",
"https://www.amazon.co.uk/City-manager-demonstration-Wellsburg-Virginia/dp/B00071R94W",
"http://www.bgky.org/assets/files/VAMSA06d.pdf",
"https://fox17.com/news/local/bowling-green-hopes-to-tap-immigrants-to-fill-job-openings",
"https://www.aspanet.org/ASPADocs/PA%20Times/Magazine/PSRW2016.pdf",
"https://www.zoominfo.com/people/Kevin/Defebbo",
"https://www.lyonsfs.com/memorials/sr-anne-dorice--defebbo-osf/4215340/",
"https://www.bginternationalfest.com/news/bg-city-calendar-features-bg-international-fest/",
"https://mydigitalpublication.com/publication/?i=361036&p=30&pp=1&view=issueViewer",
"https://www.firerescue1.com/fire-chief/articles/new-fire-chief-named-in-ky-TWfG8FYneQXZCUYr/",
"https://westernkentuckyuniversity.pastperfectonline.com/bysearchterm?keyword=Bowling+Green+Technical+College+%28Bowling+Green%2C+KY%29",
"https://westernkentuckyuniversity.pastperfectonline.com/childbylink?id=C5C22063-9D33-45F5-8FA6-313928579639",
"https://www.wku.edu/pcal/news/index.php?view=article&articleid=45",
"http://www.pointhog.com/IceHockey/League/ScoreSheet.aspx?rigORuMM5aa0aM",
"https://www.fox19.com/story/34421588/bowling-green-there-was-no-massacre",
"https://nuwber.com/person/563a4503cf00835c7f264d0d",
"https://www.section2hockey.com/teams/?u=CDHSHL&t=c&s=hockey&p=custom&pagename=Leaders_2004-2005",
"https://revitalization.org/article/bowling-green-kentucky-enjoys-a-decade-of-downtown-revitalization-thanks-to-tif-district/",
"https://beechtreenews.com/articles/cheryl-hughes-learning-curve",
"https://www.timesunion.com/local/article/The-view-is-better-thanks-to-a-big-fan-559271.php",
"https://www.wtvq.com/2017/08/08/kentucky-city-hopes-tap-immigrants-fill-job-openings/",
"https://apnews.com/3cd7812ab4cd9672084caf61b5bd238e",
"https://www.peekyou.com/kevin_defebbo",
"https://www.myheritage.com/names/kevin_defebbo",
"https://wgme.com/news/nation-world/bowling-green-mayor-issues-statement-following-kellyanne-conway-use-of-massacre",
"http://www.bgchamber.com/news/2018/02/09/main/bowling-green-area-chamber-celebrates-the-many-successes-of-2017-at-annual-dinner/",
"https://www.wymt.com/content/news/Kentucky-city-hopes-to-tap-immigrants-to-fill-job-openings-439189893.html",
"https://clustrmaps.com/person/Defebbo-7ne5bh",
"https://www.profeval.com/evaluations/view.asp?CurSchoolID=908&Subject=PS&CallNumber=110&LName=&Sort=5&ID=20460",
"https://centennial.legion.org/pennsylvania/post223/1991/04/02/flag-donation",
]

# open all the links in chrome
for link in good_links:
    webbrowser.get('chrome').open_new_tab(link)
# sleep while tabs load
sleep(60)

# must install 'keyboard' with pip and grant access to script
# for tab in range(len(good_links)):
#     keyboard.send("command+w")
